x=50
name='Thor'
print(x)
print(name)
